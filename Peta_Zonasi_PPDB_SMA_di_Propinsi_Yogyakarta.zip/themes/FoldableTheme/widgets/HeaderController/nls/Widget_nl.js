// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/FoldableTheme/widgets/HeaderController/nls/strings":{_widgetLabel:"Controller van koptekst",signin:"Aanmelden",signout:"Meld u af",about:"Over",signInTo:"Meld u aan bij",cantSignOutTip:"Deze functie is niet beschikbaar in de voorbeeldmodus.",more:"meer",_localized:{}}});